<?php
ob_start(); // Mulai output buffering
require('fpdf/fpdf.php'); // Pastikan file fpdf.php dimuat dengan benar

// Debugging: Cek apakah kelas FPDF dikenali
if (!class_exists('FPDF')) {
	die('Kelas FPDF tidak ditemukan. Pastikan file fpdf.php telah dimuat dengan benar.');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$age = $_POST['age'];
	$height = $_POST['height'];
	$weight = $_POST['weight'];
	$gender = $_POST['gender'];

	// Convert height from cm to meters
	$heightInMeters = $height / 100;

	// Calculate BMI
	$bmi = $weight / ($heightInMeters * $heightInMeters);
	$bmi = round($bmi, 2);

	// Determine BMI category
	$category = '';
	if ($bmi < 18.5) {
		$category = 'Kekurangan Berat Badan';
		$catatan = "Anda perlu meningkatkan asupan nutrisi dan mempertimbangkan konsultasi dengan ahli gizi.";
	} elseif ($bmi >= 18.5 && $bmi < 24.9) {
		$category = 'Normal (Ideal)';
		$catatan = "Berat badan Anda berada dalam rentang sehat. Terus pertahankan pola makan dan gaya hidup sehat.";
	} elseif ($bmi >= 25 && $bmi < 29.9) {
		$category = 'Kelebihan Berat Badan';
		$catatan = "Pertimbangkan untuk meninjau kembali pola makan dan rutin berolahraga untuk menjaga kesehatan.";
	} else {
		$category = 'Kegemukan (Obesitas)';
		$catatan = "Disarankan untuk berkonsultasi dengan dokter atau ahli gizi untuk merencanakan strategi pengelolaan berat badan yang sehat.";
	}

	// Jika tombol Download PDF ditekan
	if (isset($_POST['download_pdf'])) {
		// Generate PDF file with the result
		class PDF extends FPDF
		{
			function Header()
			{
				$this->SetFont('Arial', 'B', 12);
				$this->Cell(0, 10, 'Hasil Kalkulasi BMI', 0, 1, 'C');
			}

			function Footer()
			{
				$this->SetY(-15);
				$this->SetFont('Arial', 'I', 8);
				$this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
			}
		}

		$pdf = new PDF();
		$pdf->AddPage();
		$pdf->SetFont('Arial', '', 12);

		$pdf->Cell(0, 10, "Umur: $age years", 0, 1);
		$pdf->Cell(0, 10, "Tinggi Badan: $height cm", 0, 1);
		$pdf->Cell(0, 10, "Berat Badan: $weight kg", 0, 1);
		$pdf->Cell(0, 10, "Jenis Kelamin: $gender", 0, 1);
		$pdf->Cell(0, 10, "Hasil BMI: $bmi", 0, 1);
		$pdf->Cell(0, 10, "Kategori: $category", 0, 1);
		$pdf->Cell(0, 10, "Catatan: $catatan", 0, 1);

		ob_end_clean(); // Bersihkan buffer output
		$pdf->Output('D', 'hasil_bmi.pdf');
		exit();
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Hasil BMI</title>
	<link rel="stylesheet" href="css/styles.css">
</head>

<body>
	<div class="container">
		<h1><?php echo $category; ?></h1>
		<div class="result">
			<h2><?php echo $bmi; ?></h2>
			<p><?php echo $catatan; ?></p>
		</div>
		<div class="buttons">
			<form action="result.php" method="post">
				<input type="hidden" name="age" value="<?php echo htmlspecialchars($age); ?>">
				<input type="hidden" name="height" value="<?php echo htmlspecialchars($height); ?>">
				<input type="hidden" name="weight" value="<?php echo htmlspecialchars($weight); ?>">
				<input type="hidden" name="gender" value="<?php echo htmlspecialchars($gender); ?>">
				<button type="submit" name="download_pdf">Download Hasil</button>
			</form>
			<a href="index.php" class="button">Kembali</a>
		</div>
	</div>
	<script src="js/script.js"></script>
</body>

</html>