<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Kalkulator BMI</title>
	<link rel="stylesheet" href="css/styles.css">
</head>

<body>
	<div class="container">
		<h1>Kalkulator BMI</h1>
		<form action="result.php" method="post">
			<label for="age">Umur (tahun):</label>
			<input type="number" id="age" name="age" required>

			<label for="height">Tinggi Badan (cm):</label>
			<input type="number" id="height" name="height" required>

			<label for="weight">Berat Badan (kg):</label>
			<input type="number" id="weight" name="weight" required>

			<fieldset>
				<legend>Jenis Kelamin :</legend>
				<div class="gender-options">
					<label>
						<input type="radio" id="male" name="gender" value="laki-laki" required>
						Laki-laki
					</label>
					<label>
						<input type="radio" id="female" name="gender" value="Wanita" required>
						Wanita
					</label>
				</div>
			</fieldset>

			<div class="buttons">
				<button type="submit" name="calculate">Hitung BMI</button>
				<button type="reset">Reset</button>
			</div>
		</form>
	</div>
	<script src="js/script.js"></script>
</body>

</html>